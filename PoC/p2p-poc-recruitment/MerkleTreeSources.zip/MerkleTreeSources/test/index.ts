import { expect } from "chai";
import keccak256 from "keccak256";
import { ethers } from "hardhat";
import { MerkleTree } from "merkletreejs";
import { Contract } from "ethers";

describe("MerkleTreeAuth", function () {
  let contract: Contract;
  let merkleTree: MerkleTree;

  // getAccounts will return an array of accounts.
  const getAccounts = async () => {
    // You must use ethers to get the loaded accounts.
    const accs = [];
    return [
      accs[0].address,
      accs[1].address,
    ];
  }

  // getLeafNodes will return an array of leaf nodes.
  const getLeafNodes = (accounts: string[]) => {
    // Build the leaf nodes array using the accounts.
    return [];
  }

  // buildTree will build a MerkleTree from the given array of account.
  // It returns the merkle root.
  const buildMerkelTree = async (accounts: string[]) => {
    const leafNodes = getLeafNodes(accounts);

    // Build the Merkle tree and get the Merkle tree hex root.
    merkleTree = new MerkleTree(leafNodes, keccak256, { sort: true });

    return merkleTree.getHexRoot();
  }

  it("Should deploy the contract correctly", async function () {
    // Get the accounts.
    const accounts = await getAccounts();

    // Build the merkle tree.
    const merkleRoot = await buildMerkelTree(accounts);

    // Deploy the Merkle tree authentication contract.
    const MerkleTreeAuth = await ethers.getContractFactory("MerkleTreeAuth");
    contract = await MerkleTreeAuth.deploy(merkleRoot);
    await contract.deployed();
  });

  describe("Authentication", async () => {
    it("Should authenticate a valid account", async () => {
      // Get the valid account.
      const leafUser0 = getLeafNodes((await ethers.getSigners()).map(acc => acc.address))[0];
      // Build a proof using the account.
      const proof = [];

      await expect(await contract.connect(ethers.provider.getSigner(0)).isAuthorized(proof)).to.be.true;
    });

    it("Should not authenticate an invalid account", async () => {
      // Get the invalid account.
      const leafUser2 = getLeafNodes((await ethers.getSigners()).map(acc => acc.address))[2];
      // Build a proof using the account.
      const proof = [];

      await expect(await contract.connect(ethers.provider.getSigner(2)).isAuthorized(proof)).to.be.false;
    });
  })
});
